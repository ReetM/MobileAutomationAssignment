package util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class utility {

    static Properties properties;
    static InputStream input;
    static String propertyPath = System.getProperty("user.dir") + "//src//main//resources//android.properties";
    
    public static String getProperty(String key) {
        try {
        	properties = new Properties();
			FileInputStream fis = new FileInputStream(propertyPath);
			properties.load(fis);
			if (properties.containsKey(key)) {
				System.out.println("Key exists in properties file:- " + key);
			}else {
				System.out.println("Key doesn't exists in properties file:- " + key);
			}
			return properties.getProperty(key);
        } catch (Exception ex) {
        	ex.printStackTrace();
        }
		return null;
    }
}
