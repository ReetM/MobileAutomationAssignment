package actionHelper;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import util.LoggerUtil;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class AndroidHelperMethods {
    private AndroidDriver driver;
    LoggerUtil log;
    public AndroidHelperMethods(AndroidDriver driver) {
        this.driver = driver;
    }

    public void getURL(String url) {
	  driver.get(url);
    }
    
    public void click(WebElement element) throws InterruptedException {
    	
    	try {
			WaitTillVisible(element);
			element.click();
			log.info("✔ Clicked Element " + element + " Successfully!");
		} catch (StaleElementReferenceException ex1) {
			holdExecution(4000);
			element.click();
			log.warn("⚠ Clicked Element " + element + " after catching Stale Element Exception");
		} catch (WebDriverException ex3) {
			holdExecution(4000);
			performClickByActionBuilder(element);
			log.warn("⚠ Clicked Element " + element + " after catching WebDriver Exception");
		}

    }
    
    public void findAndClick(String s) {
    	
		WebElement webElement = null;
		try {
			webElement = driver.findElement(By.xpath(s));
			WaitTillVisible(webElement);
			webElement.click();
		} catch (NoSuchElementException e1) {
			logMessage("⚠ [ELEMENT NOT FOUND] : You might have to update the locator:-" + webElement);
		} catch (StaleElementReferenceException e2) {
			logWarning("⚠ [Stale Element Exception!!] : Refinding the element after 5 seconds" + webElement);
			holdExecution(5000);
			webElement = driver.findElement(By.xpath(s));
			webElement.click();
		}
    	//driver.findElement(By.xpath(s)).click();
    }
        
     public void scrollDown() throws InterruptedException {
    	 JavascriptExecutor js = ((JavascriptExecutor) driver);
    	 js.executeScript("window.scrollBy(0,1400)");
    	 Thread.sleep(5000);
    }

    public boolean getProperty(WebElement e) {
    	System.out.println(e.isEnabled());
    	return (e.isEnabled());
    }
    public void enter(WebElement element, String input) {
        element.clear();
        element.sendKeys(input);
        System.out.println("Element is getting entered" + input);
    }
    public void inputValuesSlowly(MobileElement element, String value) {
        try {
            String val = value;
            for (int i = 0; i < val.length(); i++) {
                char c = val.charAt(i);
                String s = new StringBuilder().append(c).toString();
                System.out.println(s);
                element.setValue(s);
                Thread.sleep(100);
            }
        } catch (Exception e) {
            System.out.println("Not able to enter" + e.getMessage());
        }
    }
    public void switchContext(String contextHandler) {
    	//Set<String> contextNames = driver.getContextHandles();
    	if(contextHandler.equalsIgnoreCase("NATIVE_APP")){
		driver.context("NATIVE_APP");
 		}
		if(contextHandler.equalsIgnoreCase("CHROMIUM")){
		driver.context("CHROMIUM");
 		}
    }
    
    public void WaitTillVisible(WebElement element){
		try {
	        new WebDriverWait(driver,10).until(ExpectedConditions.visibilityOf(element));
		} catch (Throwable e) {
			logWarning("Element not visible...");
		}
    }
    
    public void dissmissPopUp() {
    	Alert alert =driver.switchTo().alert();
    	alert.accept();
    	
    }
    
    public void verifyPageURLLoaded(String expected) {
		logMessage("Expected URL: " + expected);
		logMessage("Actual URL: " + driver.getCurrentUrl());
    	Assert.assertEquals(expected,driver.getCurrentUrl(),"Page Not Loaded Succesfully");
    }
    
    public void verifyTextOnPage(WebElement element,String Expected) {
		logMessage("Expected text: " + Expected);
		logMessage("Actual text: " + element.getText());
    	Assert.assertEquals(Expected,element.getText(),"Page Not Loaded Properly");
    }

	public void logMessage(String message) {
		log.info("✔  " + message);
	}
	
	//
	public void logWarning(String message) {
		log.warn("⚠ " + message);
	}
	
	//
	public void logError(String message) {
		log.error("❌" + message);
	}
	
	public void holdExecution(int milliSeconds) {
		try {
			Thread.sleep(milliSeconds);
		} catch (InterruptedException e) {
			logMessage("Failed while trying to halt execution!");
			e.printStackTrace();
		}
	}
	
	public void performClickByActionBuilder(WebElement element) {
		Actions builder = new Actions(driver);
		builder.moveToElement(element).build().perform();
		builder.moveToElement(element).click().perform();
	}
}
