package AndroidDriverManager;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import util.utility;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class AndroidDriverManager {
    Properties properties;
    static DesiredCapabilities capabilities;
    AndroidDriver driver;
    public AndroidDriver getAndroidDriver(){
        try {
        
            String platformVersion = utility.getProperty("platformVersion");
            String deviceName = utility.getProperty("deviceName");
            String nodeURL = utility.getProperty("nodeURL");
            String platformName = utility.getProperty("platformName");
            //Set Capabilities
            capabilities = new DesiredCapabilities();
            capabilities.setCapability("platformVersion", platformVersion);
            capabilities.setCapability("deviceName", deviceName);
            capabilities.setCapability(CapabilityType.BROWSER_NAME, "Chrome"); 
            capabilities.setCapability("platformName", platformName);
            capabilities.setCapability("autoGrantPermissions", "true");
            return driver = new AndroidDriver(new URL(nodeURL), capabilities);

        } catch (Exception e) {
            System.out.println("Not able to create Android Driver " + e.getMessage());
        }
        return driver;
    }
}
