package Pages;


import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import util.utility;


public class DemoPage extends BasePageClass {

    public static final String BlockPopUp_BTN = "//*[text()='Ignore']";
	public static final String search_BTN ="//*[contains(@text,'Menu')]";
    public static final String explore_SideMenu="//*[local-name()='svg' and @data-automation='burger-menu-icon']/..";
    public static final String women_Menu="//a[@href='/c/women' and @data-key='/women']";
    public static final String women_ClothingMenu="//a[@href='/c/women/clothing' and @data-key='/women/clothing']";
    public static final String women_dressMenu="//a[@href='/c/women/clothing/dresses' and @data-key='/women/clothing/dresses']";
    public static final String women_CocktailDress="//*[@data-automation='tile-category-name' and text()='Cocktail & Party Dresses']";
    public static final String select_Dress="//*[@data-automation='product-grid-item'][1]";
    public static final String add_ToBag="//*[text()='Add to bag']";
 //   public static final String size="//*[@id='size-XS']";
    public static final String size=" //*[@name='size']";
    public static final String verifyCartSuccess="//*[text()='Item successfully added to Bag']";
    public static final String checkOutFromCart="//button[text()='VIEW BAG AND CHECKOUT']";
    public static final String verifyBagCount="//*[@data-automation='mini-bag-count']";
    public static final String verifyWomenDressesPage="//*[@data-automation='product-listing-title']/span[@class='screen-reader-text']";
   
   @FindBy(xpath=BlockPopUp_BTN)
   WebElement BlockPopUpBtn;
   
   @FindBy(xpath = explore_SideMenu)
   WebElement sideMenu;
   
   @FindBy(xpath = women_Menu)
   WebElement womenMenu;

   @FindBy(xpath = women_ClothingMenu)
   WebElement womenClothing;
   
   @FindBy(xpath = women_dressMenu)
   WebElement womenDresses;
   
   @FindBy(xpath = women_CocktailDress)
   WebElement womenCocktailDress;
   
   @FindBy(xpath = select_Dress)
   WebElement selectDresss;
   
   @FindBy(xpath = add_ToBag)
   WebElement addToBag;
   
  @FindAll(@FindBy(xpath=size))
   List<WebElement> sizes;
    
  @FindBy(xpath=verifyCartSuccess)
  WebElement verifyItemAddedSuccessfuly;
  
  
  @FindBy(xpath=verifyWomenDressesPage)
  WebElement verifyWomenDressPageTitle;
  
  @FindBy(xpath=checkOutFromCart)
  WebElement checkOutCartBtn;
  
  @FindBy(xpath=verifyBagCount)
  WebElement verifyNumberOfItemsInBag;
  
    public DemoPage(AndroidDriver driver) {
        super(driver);
    }
   // Properties properties;

    public void launchBrowserURL() throws InterruptedException {
    	androidHelperMethods.getURL(utility.getProperty("URL"));
    	androidHelperMethods.verifyPageURLLoaded(utility.getProperty("URL"));
    	androidHelperMethods.switchContext("NATIVE_APP");
    	androidHelperMethods.dissmissPopUp();
    }
    public void selectItem() throws InterruptedException {
    	
    	androidHelperMethods.switchContext("CHROMIUM");
    	androidHelperMethods.click(BlockPopUpBtn);
    	androidHelperMethods.click(sideMenu);
    	androidHelperMethods.click(womenMenu);
    	androidHelperMethods.click(womenClothing);
    	androidHelperMethods.click(womenDresses);
    	androidHelperMethods.verifyTextOnPage(verifyWomenDressPageTitle, "Women's Dresses");
    	androidHelperMethods.click(womenCocktailDress);
    	androidHelperMethods.verifyTextOnPage(verifyWomenDressPageTitle, "Women's Cocktail & Party Dresses");
    	androidHelperMethods.click(selectDresss);	
    }
    
	public void selectDressSize() throws InterruptedException {
    	int i=1;
    	for(WebElement e: sizes) {	
    		boolean bool=androidHelperMethods.getProperty(e);
    		if(bool==true) {
    			String availableSize="//*[@class='css-1iketlu']["+i+"]/label";
    			androidHelperMethods.scrollDown();
    			androidHelperMethods.findAndClick(availableSize);
    			break;
    		}
    		else
    			i++;
    	}
	}
	public void addItemToCart() throws InterruptedException {
    	androidHelperMethods.click(addToBag);
    	androidHelperMethods.verifyTextOnPage(verifyItemAddedSuccessfuly, "Item successfully added to Bag");
	}
	public void viewBagAndCheckOut() throws InterruptedException {
    	androidHelperMethods.click(checkOutCartBtn);
    	androidHelperMethods.verifyTextOnPage(verifyNumberOfItemsInBag, "1");
	}
}
