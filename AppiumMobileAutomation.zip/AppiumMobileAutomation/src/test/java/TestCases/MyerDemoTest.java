package TestCases;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;


import AndroidDriverManager.AndroidDriverManager;
import Pages.DemoPage;
import io.appium.java_client.android.AndroidDriver;

public class MyerDemoTest extends AndroidDriverManager {
	    AndroidDriver driver;
	    DemoPage demoPage;
	    AndroidDriverManager driverManager=new AndroidDriverManager();
	@BeforeSuite
    public void setUp() {
        try {
         	driver= driverManager.getAndroidDriver();
            demoPage = new DemoPage(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
	
    @Test
    public void TEST_CASE_ONE() throws Exception {

    	demoPage.launchBrowserURL();
    	demoPage.selectItem();
    	demoPage.selectDressSize();
    	demoPage.addItemToCart();
    	demoPage.viewBagAndCheckOut();

    }
    @AfterSuite
    public void quitDriver() {
         driver.quit();
    }
}
